
///// DarkMode///////////


let themeButton = document.getElementById("theme-button");
// TODO: Complete the toggleDarkMode function
const toggleDarkMode = () => {

    document.body.classList.toggle("dark-mode");


}

// TODO: Register a 'click' event listener for the theme button
// Set toggleDarkMode as the callback function.
themeButton.addEventListener("click", toggleDarkMode);
// scrolling !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1
let animation = {
    revealDistance: 150,
    initialOpacity: 0,
     transitionDelay: 0,
    transitionDuration: '2s',
    transitionProperty: 'all',
     transitionTimingFunction: 'ease'

}
let lastScrollTop = 0; // Keeps track of the last scroll position

// Function to handle scroll event
window.addEventListener('scroll', () => {
  const revealables = document.querySelectorAll('.revealable');
  const currentScroll = window.scrollY; // Get the current scroll position
  
  // Check if scrolling down
  if (currentScroll > lastScrollTop) {
    // If scrolling down, check each revealable element
    revealables.forEach(revealable => {
      const elementTop = revealable.getBoundingClientRect().top;
      if (elementTop < window.innerHeight * 0.8) {  // Element is 80% visible
        revealable.classList.add('active');
      }
    });
  } else {
    // If scrolling up, do nothing or remove the active class if you want to reset
    revealables.forEach(revealable => {
      revealable.classList.remove('active');
    });
  }

  // Update the last scroll position
  lastScrollTop = currentScroll;
});

///////Petition///////
// Add your query for the sign now button here
let signNowButton = document.getElementById("sign-now-button");
const addSignature = (person) => {
    
     // Create a new paragraph element to hold the signature
     const newSignature = document.createElement("p");
     newSignature.textContent= ` 🖊️ ${person.name} from ${person.hometown} has signed the petition!`;

     document.querySelector(".signatures").appendChild(newSignature);

}


//Validate form mehtod
const validateForm = () =>
{
    let containsErrors = false;
  
    let petitionInputs = document.getElementById("sign-petition").elements;
    let person = {
        name: petitionInputs[0].value, // accesses and saves value of first input
        hometown: petitionInputs[1].value 
      }

      for (let i = 0; i < petitionInputs.length; i++) {
        if (petitionInputs[i].value.length < 2) {
            petitionInputs[i].classList.add('error');
            containsErrors = true;
        } else {
            petitionInputs[i].classList.remove('error');
        }
    }

    if (!containsErrors) {
        addSignature(person);
        toggleModal(person);   // Call toggleModal to display the modal
        for (let i = 0; i < petitionInputs.length; i++) {
            petitionInputs[i].value = ""; // Clear input fields
        }
    }
    
    
}  
  
  
  signNowButton.addEventListener('click', (event) => {
    
    validateForm(); // Validate the form and trigger actions
    
});
  //modal Method
  // Variables outside any function
let scaleFactor = 1;
const modalImage = document.getElementById("picture"); // Select the image within the modal

// Function to scale the image
const scaleImage = (image) => {
    if (scaleFactor === 1) {
        scaleFactor = 0.1;  // Shrink the image
    } else {
        scaleFactor = 1;  // Restore the original size
    }

    // Apply the scale factor to the image's transform property
    modalImage.style.transform = `scale(${scaleFactor})`;
};

  const toggleModal =  (person) =>
  {
    const modal= document.getElementById("thanks-modal");
    const modalContent = document.getElementById("modal-text-container");

    modal.style.display = "flex";
    modalContent.innerHTML = `<p>Thank you, ${person.name}, ${person.hometown}, for signing the petition!</p>`;

    // Set up the interval to animate the image
    const intervalId = setInterval(() => scaleImage(modalImage), 500);  // Every 500ms (half a second)

      // timeout for moda;
    setTimeout(() => {
        modal.style.display = "none";
        clearInterval(intervalId);    // Clear the interval to stop animation
      }, 4000)
  }

  
